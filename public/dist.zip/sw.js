/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-990a494f'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "eba41965acd603c8cc80dbb2c7aa2922"
  }, {
    "url": "pwa-512x512.png",
    "revision": "82d411bdf42241a09b832bb9ce0083bb"
  }, {
    "url": "pwa-192x192.png",
    "revision": "112a8c9250b76fc2d890fb5b04cc42c8"
  }, {
    "url": "logo.png",
    "revision": "f5256e6a286bf62bf4ffd577d382267d"
  }, {
    "url": "index.html",
    "revision": "6abcb41d38478c1ba1e47da1a97e0aec"
  }, {
    "url": "favicon.ico",
    "revision": "2d5e91b51afeb9255275d576cdd8299a"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "112a8c9250b76fc2d890fb5b04cc42c8"
  }, {
    "url": "assets/workbox-window.prod.es5-Bd17z0YL.js",
    "revision": null
  }, {
    "url": "assets/index-BTVxpCOi.js",
    "revision": null
  }, {
    "url": "assets/index-B7h1Vyqe.css",
    "revision": null
  }, {
    "url": "assets/images/mission_boat.png",
    "revision": null
  }, {
    "url": "assets/images/logo_square2.png",
    "revision": null
  }, {
    "url": "assets/images/logo_square.png",
    "revision": null
  }, {
    "url": "assets/images/logo_raw.png",
    "revision": null
  }, {
    "url": "assets/images/logo_clean.png",
    "revision": null
  }, {
    "url": "assets/images/logo.png",
    "revision": null
  }, {
    "url": "assets/images/hero_plant_clean.png",
    "revision": null
  }, {
    "url": "assets/images/hero_plant.png",
    "revision": null
  }, {
    "url": "assets/images/hero_img.png",
    "revision": null
  }, {
    "url": "assets/images/hero_full_banner.png",
    "revision": null
  }, {
    "url": "assets/images/header_logo_wider.png",
    "revision": null
  }, {
    "url": "assets/images/header_crop.png",
    "revision": null
  }, {
    "url": "assets/images/foundation_logo.png",
    "revision": null
  }, {
    "url": "assets/images/footer_logo.png",
    "revision": null
  }, {
    "url": "assets/images/cards_area.png",
    "revision": null
  }, {
    "url": "assets/images/bottom_area.png",
    "revision": null
  }, {
    "url": "assets/images/boat_img.png",
    "revision": null
  }, {
    "url": "assets/aistudio/file_00000000a24c82118f9b34727bbf3f25_8f131ec6.png",
    "revision": null
  }, {
    "url": "assets/aistudio/file_0000000024bc824385c1f476e948c71a_16f245c6.png",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "112a8c9250b76fc2d890fb5b04cc42c8"
  }, {
    "url": "favicon.ico",
    "revision": "2d5e91b51afeb9255275d576cdd8299a"
  }, {
    "url": "pwa-192x192.png",
    "revision": "112a8c9250b76fc2d890fb5b04cc42c8"
  }, {
    "url": "pwa-512x512.png",
    "revision": "82d411bdf42241a09b832bb9ce0083bb"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "eba41965acd603c8cc80dbb2c7aa2922"
  }, {
    "url": "assets/images/foundation_logo.png",
    "revision": "f5256e6a286bf62bf4ffd577d382267d"
  }, {
    "url": "manifest.webmanifest",
    "revision": "4039e80c5ea102d47b9f3922eae4c535"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("/index.html")));
  workbox.registerRoute(({
    request
  }) => request.mode === "navigate", new workbox.NetworkFirst({
    "cacheName": "html-pages-cache",
    "networkTimeoutSeconds": 3,
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 604800
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
